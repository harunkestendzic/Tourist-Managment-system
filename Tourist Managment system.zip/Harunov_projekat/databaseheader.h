#ifndef DATABASEHEADER_H
#define DATABASEHEADER_H

#include <QSqlDatabase>
#include <QSQlDriver>
#include <QSqlError>
#include <QDebug>
#include <QSqlQuery>
#include <QSqlTableModel>
#include <QFile>

#endif // DATABASEHEADER_H
